from django.urls import path
from . import views

app_name = 'waste_classifier'

urlpatterns = [
    path('', views.index, name='index'),
    path('upload/', views.upload_image, name='upload_image'),
    path('save-score/', views.save_score, name='save_score'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('add-leaderboard/', views.add_leaderboard_entry, name='add_leaderboard_entry'),
    path('history/', views.history, name='history'),
    path('recycling-info/', views.get_recycling_info, name='get_recycling_info'),
] 